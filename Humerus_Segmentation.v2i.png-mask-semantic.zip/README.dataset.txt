# Humerus_Segmentation > 2023-06-12 7:43pm
https://universe.roboflow.com/humerussegmentation/humerus_segmentation

Provided by a Roboflow user
License: CC BY 4.0

